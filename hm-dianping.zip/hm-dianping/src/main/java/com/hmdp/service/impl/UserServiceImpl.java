package com.hmdp.service.impl;

import cn.hutool.core.util.RandomUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hmdp.dto.LoginFormDTO;
import com.hmdp.dto.Result;
import com.hmdp.entity.User;
import com.hmdp.mapper.UserMapper;
import com.hmdp.service.IUserService;
import com.hmdp.utils.RegexUtils;
import jdk.nashorn.internal.ir.CallNode;
import lombok.val;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;

import static com.hmdp.utils.SystemConstants.USER_NICK_NAME_PREFIX;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author 虎哥
 * @since 2021-12-22
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements IUserService {

    @Override
    public Result sendCode(String phone, HttpSession session) {
        // 1. Check your phone number
        if (RegexUtils.isPhoneInvalid(phone)) {
            // 2. If not, an error message is returned
            return Result.fail("The format of the phone number is wrong!");
        }
        // 3. If so, a CAPTCHA is generated
        String code = RandomUtil.randomNumbers(6);
        // 4. Save the CAPTCHA to the session.
        session.setAttribute("code",code);
        // 5. Send CAPtCHA
        log.debug("Send SMS verification code successfully, verification code:" + code);
        // return ok
        return Result.ok();
    }

    @Override
    public Result login(LoginFormDTO loginForm, HttpSession session) {
        // 1. Check your phone number
        String phone = loginForm.getPhone();
        if (RegexUtils.isPhoneInvalid(phone)) {
            // 2. If not, an error message is returned
            return Result.fail("The format of the phone number is wrong!");
        }
        // 2. Verify the CAPtCHA
        Object cacheCode = session.getAttribute("code");
        String code = loginForm.getCode();
        if (cacheCode == null || !cacheCode.toString().equals(code)) {
            // 3. Inconsistent, error
            return Result.fail("Captcha error");
        }

        // 4. Consistently, users are queried based on their mobile phone number select * from tb_user where phone = ?
        User user = query().eq("phone", phone).one();
        // 5. Determines if the user exists
        if (user == null){
            // 6. Does not exist, create a new user and save it.
            user = createUserWithPhone(phone);
        }

        // 7. Save user information to the session.
        session.setAttribute("user",user);
        return Result.ok();
    }

    private User createUserWithPhone(String phone) {
        // 1. Create the User
        User user = new User();
        user.setPhone(phone);
        user.setNickName(USER_NICK_NAME_PREFIX + RandomUtil.randomString(10));
        // 2. Save the User
        save(user);
        return user;
    }
}
